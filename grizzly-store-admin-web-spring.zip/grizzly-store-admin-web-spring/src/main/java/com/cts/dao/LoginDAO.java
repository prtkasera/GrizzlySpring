package com.cts.dao;

import com.cts.entity.Login;

public interface LoginDAO {

	public String getUserType(String userId);
	public Login authenticate(String userName, String password);
}
