package com.cts.dao;

import java.util.List;

import com.cts.entity.Category;

public interface CategoryDAO {
	public List<Category> getAllCategory();
}
