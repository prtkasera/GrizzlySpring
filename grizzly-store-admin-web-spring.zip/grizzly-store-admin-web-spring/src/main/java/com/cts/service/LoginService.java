package com.cts.service;

import com.cts.entity.Login;

public interface LoginService {

	public String getUserType(String userId);
	public Login authenticate(String userName, String password);
}
